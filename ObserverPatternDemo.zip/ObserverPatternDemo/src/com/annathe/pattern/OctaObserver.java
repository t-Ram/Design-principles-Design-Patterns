package com.annathe.pattern;

public class OctaObserver extends Observer {
	
	public OctaObserver(Subject subject) {
		
		this.subject = subject;
		this.subject.subscribe(this);
	}

	@Override
	protected void update() {
		
		System.out.println("Octa String "+ Integer.toOctalString(subject.getState()));
	}

}
