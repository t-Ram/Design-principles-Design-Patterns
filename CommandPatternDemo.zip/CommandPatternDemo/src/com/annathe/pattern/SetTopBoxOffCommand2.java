package com.annathe.pattern;

public class SetTopBoxOffCommand2 implements Command {

	private SetTopBox setTopBox;
	
	
	public SetTopBoxOffCommand2(SetTopBox setTopBox) {
		super();
		this.setTopBox = setTopBox;
	}


	public void execute() {
		
		setTopBox.off();
		
	}

}
