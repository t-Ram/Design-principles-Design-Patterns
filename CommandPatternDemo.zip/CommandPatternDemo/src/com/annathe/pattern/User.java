package com.annathe.pattern;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RemoteControl remote = new RemoteControl();
		
		SetTopBox setTopBox = new SetTopBox();
		
		remote.setCommand(new SetTopBoxOnCommand(setTopBox));
		
		remote.pressButton();

	}

}
