package com.annathe.pattern;

public class SetTopBoxOnCommand implements Command {

	private SetTopBox setTopBox;
	
	
	public SetTopBoxOnCommand(SetTopBox setTopBox) {
		super();
		this.setTopBox = setTopBox;
	}


	public void execute() {
		
		setTopBox.on();
		setTopBox.setChannel();
		setTopBox.setVolume();
	}

}
