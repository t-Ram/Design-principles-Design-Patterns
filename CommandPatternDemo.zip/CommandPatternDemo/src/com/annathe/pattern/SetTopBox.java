package com.annathe.pattern;

public class SetTopBox {
	
	public void on() {
		
		System.out.println("Settopbox is on");
	}

public void off() {
		
	System.out.println("Settopbox is off");
	}

public void setChannel() {
	
	System.out.println("Settopbox channel is set to default channel");
}

public void setVolume() {
	
	System.out.println("Settopbox volume is set to default volume");
}
	
}
