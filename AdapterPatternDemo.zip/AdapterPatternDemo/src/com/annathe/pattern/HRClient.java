package com.annathe.pattern;

import java.util.ArrayList;
import java.util.List;

public class HRClient {
	
	
			
		
		public static void main(String arg[]) {
			
			
			List<String[]> employeeList = getEmployeeDetails() ;
			
			BillingSystemAdapter bs = new BillingSystemAdapter();
			
			bs.processDetails(employeeList);
			
		}
		
		
	private static List<String[]> getEmployeeDetails() {
		
		String [] employee1 = {"100","Kumar", "manager"};
		
		String [] employee2 = {"101","Guru", "team lead"};
		
		String [] employee3 = {"103","Ravi", "analyst"};
		
		List employeeList = new ArrayList();
		
		
		employeeList.add(employee1);
		
		employeeList.add(employee2);
		
		employeeList.add(employee3);
		
		return employeeList;
		
	}



}
	


