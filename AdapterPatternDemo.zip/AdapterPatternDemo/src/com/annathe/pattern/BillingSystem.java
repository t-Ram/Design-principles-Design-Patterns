package com.annathe.pattern;

import java.util.List;

public class BillingSystem {
	
	
	public void processDetails(List<Employee> employeeList) {
		
		//Bill processing
		
	}

}
