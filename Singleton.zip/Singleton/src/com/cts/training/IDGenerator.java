package com.cts.training;

public class IDGenerator {
	
	private int id;
	
	private static IDGenerator obj = new IDGenerator();
	
	public int getId() {
		
		++id;
		return id;
	}

	

	private IDGenerator() {
		
		
	}
	
	public static IDGenerator getObject() {
		
		return obj;
		
	}

}
