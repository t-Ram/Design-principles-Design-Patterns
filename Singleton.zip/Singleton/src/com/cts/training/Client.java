package com.cts.training;

public class Client {
	
	public static void main(String arg[]) {
		
		IDGenerator idgen = IDGenerator.getObject();
		
		int id = idgen.getId();
		
		System.out.println("id: "+id);
		
		IDGenerator idgen1 = IDGenerator.getObject();
		
		int id1 = idgen1.getId();
		
		System.out.println("id1: "+id1);
		
		
	}

}
