package com.annathe.pattern;

public class ChickenPizzaDecorator extends PizzaDecorator {

	public ChickenPizzaDecorator(Pizza pizza) {
		super(pizza);
		// TODO Auto-generated constructor stub
	}
	
	
	public String makePizza() {
		// TODO Auto-generated method stub
		return "Plain Pizza" +addChicken();
	}


	public String addChicken() {
		
		return " Chicken added ";
	}

}
