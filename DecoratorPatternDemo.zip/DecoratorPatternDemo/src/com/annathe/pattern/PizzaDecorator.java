package com.annathe.pattern;

public abstract class PizzaDecorator implements Pizza{
	
	private Pizza pizza;

	public PizzaDecorator(Pizza pizza) {
		super();
		this.pizza = pizza;
	}
	
	
	public String makePizza() {
		// TODO Auto-generated method stub
		return "Plain Pizza";
	}
}
