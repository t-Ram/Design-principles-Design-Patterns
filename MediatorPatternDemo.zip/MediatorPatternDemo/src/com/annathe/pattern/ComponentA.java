package com.annathe.pattern;

public class ComponentA extends Component {

	public ComponentA(Mediator m) {
		
		super("Component-A",m);
	}
	
	
	@Override
	public void send() {
		String message ="I am good";
		
		System.out.println("Component A is sending "+message);
		mediator.notify(this,message);

	}

	@Override
	public void receive(String message) {
		// TODO Auto-generated method stub
		System.out.println("Component A received the message "+message);
	}

}
