package com.annathe.pattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Mediator m = new ConcreteMediator();
		
		Component compA = new ComponentA(m);
		
		Component compB = new ComponentB(m);
		
		m.register(compA);
		m.register(compB);
		
		compB.send();
	}

}
