package com.annathe.pattern;

public class LaptopFactory extends AbstractDeviceFactory{

	@Override
	public Device getGadget(String deviceType) {
		
		switch(deviceType) {
		
		case "HP":
		return new HP();
		
		case "Dell":
		return new Dell();
		
		
	}

	return null;
}
	
}