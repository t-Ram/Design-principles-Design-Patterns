package com.annathe.pattern;

public class Nokia extends Device {

	@Override
	public void getDetails() {
		
		System.out.println("Nokia details");

	}

}
