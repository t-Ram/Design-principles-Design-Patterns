package com.annathe.pattern;

public class Client {

	public static void main(String[] args) {

		
		Device Dell = FactoryGenerator.getFactory("Laptop").getGadget("Dell");

	
		Dell.getDetails();
		
		
		AbstractDeviceFactory abs = FactoryGenerator.getFactory("Mobile");
		
		Device onePlus = abs.getGadget("OnePlus");
		
		
		onePlus.getDetails();
	
	}

}
