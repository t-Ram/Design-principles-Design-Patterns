package com.annathe.pattern;

public abstract class Device {
	
	public abstract void getDetails();

}
