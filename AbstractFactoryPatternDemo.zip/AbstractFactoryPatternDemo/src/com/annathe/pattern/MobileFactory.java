package com.annathe.pattern;

public class MobileFactory extends AbstractDeviceFactory{

	@Override
	public Device getGadget(String deviceType) {
		
		switch(deviceType) {
		
		case "Nokia":
		return new Nokia();
		
		case "OnePlus":
		return new OnePlus();
		
		
	}

	return null;
}
	
}