package com.annathe.pattern;

public class OnePlus extends Device {

	@Override
	public void getDetails() {
		
		System.out.println("OnePlus details");

	}

}
