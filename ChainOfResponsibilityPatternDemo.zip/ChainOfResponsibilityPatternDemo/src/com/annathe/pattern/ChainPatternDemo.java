package com.annathe.pattern;

public class ChainPatternDemo {
	
	public static AbstractLogger getChainOfLoggers() {
		
		AbstractLogger errorLogger = new ErrorLogger(AbstractLogger.ERROR);
		
		AbstractLogger fileLogger = new FileLogger(AbstractLogger.DEBUGG);
		
		AbstractLogger consoleLogger = new ConsoleLogger(AbstractLogger.INFO);
		
		errorLogger.setNextLogger(fileLogger);
		
		fileLogger.setNextLogger(consoleLogger);
		
		return errorLogger;
				
	}
	
	public static void main(String arg[]) {
		
		AbstractLogger loggerChain = getChainOfLoggers();
		
		loggerChain.logMessage(AbstractLogger.INFO, "Thia is an information");
		
		System.out.println("----------------------------------------------");	
		
	
		loggerChain.logMessage(AbstractLogger.DEBUGG, "Thia is debugg level information");
		
		System.out.println("----------------------------------------------");	
		
		loggerChain.logMessage(AbstractLogger.ERROR, "Thia is an error information");
		
		System.out.println("----------------------------------------------");	
	
	
	}

}
