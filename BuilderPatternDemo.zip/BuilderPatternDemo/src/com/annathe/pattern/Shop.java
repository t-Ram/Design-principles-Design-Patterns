package com.annathe.pattern;

public class Shop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Phone p = new PhoneBuilder().setOs("Anderoid").setRam(4).getPhone();
		
		
		
		System.out.println(p);

	}

}
