package com.annathe.pattern;

public class OperatingSystemFactory {
	
	public static OS getInstance(String str) {
		
		
		OS os=null;
		
		if(str.equals("Open")) {
		
		 os = new Android();
		}
		else if(str.equals("Closed")) {

		 os = new IOS();
	}
	else {
		
		os = new Windows();
	}

		return os;
}
	
}