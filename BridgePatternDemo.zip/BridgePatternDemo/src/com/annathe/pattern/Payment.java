package com.annathe.pattern;

public abstract class Payment {
	
	public IPaymentSystem iPaymentSystem;
	
	public abstract void makePayment();

}
