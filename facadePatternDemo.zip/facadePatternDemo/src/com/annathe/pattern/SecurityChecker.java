package com.annathe.pattern;

public class SecurityChecker {

	public void authenticate(String userid, String password) {
		
		System.out.println("Authentication done");
	}
}
